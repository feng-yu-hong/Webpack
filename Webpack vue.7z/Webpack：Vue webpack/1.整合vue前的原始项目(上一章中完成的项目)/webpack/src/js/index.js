import "../css/main.css";
import "../less/1.less";

window.onload=function (){
  document.onclick=function (){
    //alert("a");
  };
};
