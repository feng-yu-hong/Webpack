import '../css/main.css';

alert('bug');
