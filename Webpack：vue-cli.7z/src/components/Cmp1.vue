<template lang="html">
  <div class="">
    cmp1
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
